#include "libTPIUT.h"
#include "robot.h"

int main (void)
{
	initCarte();
	configureConsole();
	while(true) {

	}
}
